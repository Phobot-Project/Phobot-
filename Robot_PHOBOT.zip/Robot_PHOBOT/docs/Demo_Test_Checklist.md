# Demo Test Checklist

Phone: Samsung Galaxy A17, Android 16, USB Type-C
Robot: Kobuki (Yujin Robot / Quanser), DC 14.8V

## Before Demo
- [ ] Kobuki powered on
- [ ] Phone charged (50%+)
- [ ] USB OTG adapter ready
- [ ] USB cable ready
- [ ] App installed on real phone (not emulator)
- [ ] Test area flat and clear

## Connection
- [ ] OTG adapter plugged into phone
- [ ] USB cable connected to Kobuki
- [ ] USB permission popup appeared
- [ ] Tapped Allow
- [ ] App opened
- [ ] Connect button pressed
- [ ] Status shows "Connected" (green)
- [ ] Device info shows VID=0x403 PID=0x6001
- [ ] Event log shows "FTDI initialized: 115200 baud, 8N1"

## Movement Control
- [ ] STOP tested first (robot stays still)
- [ ] FORWARD (robot moves forward)
- [ ] STOP (robot stops)
- [ ] BACKWARD (robot moves backward)
- [ ] STOP
- [ ] LEFT (robot spins counter-clockwise)
- [ ] STOP
- [ ] RIGHT (robot spins clockwise)
- [ ] STOP

## Event Log Check
- [ ] Log shows "Sent FORWARD [AA 55 ...]"
- [ ] Log shows hex packet data for each command
- [ ] No "FAIL" or "ERROR" messages

## Voice Control
- [ ] Microphone permission granted
- [ ] Voice button pressed, said "forward"
- [ ] Robot moved forward
- [ ] Said "stop", robot stopped

## Disconnect
- [ ] Disconnect pressed
- [ ] Status red, buttons disabled
- [ ] Reconnect tested

## Notes
Date: _______________
Tester: _____________
Issues: _____________
